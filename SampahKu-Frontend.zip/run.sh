#!/bin/bash

# --- Config ---
FRONTEND_IMAGE="frontend_img"
FRONTEND_CONTAINER="frontend_app"
NETWORK_NAME="universal_net"
API_CONTAINER_NAME="universal_api"
FRONTEND_PORT=8080

# --- Build Docker image ---
docker build -t $FRONTEND_IMAGE .

# --- Hentikan container lama kalau ada ---
if [ $(docker ps -aq -f name=$FRONTEND_CONTAINER) ]; then
    docker rm -f $FRONTEND_CONTAINER
fi

# --- Jalankan frontend container ---
docker run -d \
    --name $FRONTEND_CONTAINER \
    --network $NETWORK_NAME \
    -e NEXT_PUBLIC_API_URL="http://$API_CONTAINER_NAME:8000" \
    -p $FRONTEND_PORT:$FRONTEND_PORT \
    $FRONTEND_IMAGE

echo "Frontend berjalan di http://localhost:$FRONTEND_PORT"
echo "Terhubung ke backend container $API_CONTAINER_NAME di network $NETWORK_NAME"
